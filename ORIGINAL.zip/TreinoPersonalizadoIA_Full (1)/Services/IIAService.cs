﻿using TreinoPersonalizadoIA_Full.Models;

namespace TreinoPersonalizadoIA_Full.Services
{
    public interface IIAService
    {
        SugestaoTreino GerarTreino(UsuarioDados dados);
    }
}

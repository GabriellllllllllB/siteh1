using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using TreinoPersonalizadoIA_Full.Models;
using TreinoPersonalizadoIA_Full.Services;

namespace TreinoPersonalizadoIA_Full.Pages
{
    public class IndexModel : PageModel
    {
        private readonly IAService _iaService;

        public IndexModel(IAService iaService)
        {
            _iaService = iaService;
        }

        [BindProperty]
        public UsuarioDados DadosUsuario { get; set; }

        public SugestaoTreino SugestaoTreino { get; set; }
        public string Erro { get; set; }

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                Erro = "Preencha todos os campos corretamente.";
                return Page();
            }

            SugestaoTreino = _iaService.GerarTreino(DadosUsuario);

            if (SugestaoTreino == null)
            {
                Erro = "Erro ao gerar o treino.";
            }

            return Page();
        }
    }
}


using System.ComponentModel.DataAnnotations;

namespace TreinoPersonalizadoIA_Full.Models
{
    public class UsuarioDados
    {
        [Required(ErrorMessage = "Informe o sexo.")]
        public string Sexo { get; set; }

        [Required(ErrorMessage = "Informe a altura.")]
        [Range(1.0, 2.5, ErrorMessage = "Altura deve estar entre 1.0 e 2.5 metros.")]
        public double? Altura { get; set; }

        [Required(ErrorMessage = "Informe o peso.")]
        [Range(30, 300, ErrorMessage = "Peso deve estar entre 30 e 300 kg.")]
        public double? Peso { get; set; }

        [Required(ErrorMessage = "Informe o percentual de gordura.")]
        [Range(1, 60, ErrorMessage = "Percentual de gordura deve estar entre 1% e 60%.")]
        public double? PercentualGordura { get; set; }

        [Required(ErrorMessage = "Informe o objetivo.")]
        public string Objetivo { get; set; }

        [Required(ErrorMessage = "Informe o n�vel.")]
        public string Nivel { get; set; }
    }
}

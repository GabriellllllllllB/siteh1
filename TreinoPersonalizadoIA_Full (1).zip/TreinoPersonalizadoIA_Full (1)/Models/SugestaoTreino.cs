namespace TreinoPersonalizadoIA_Full.Models
{
    public class SugestaoTreino
    {
        public string Treino { get; set; }
        public string PlanoSemanal { get; set; }
        public string DietaSugerida { get; set; }
    }
}
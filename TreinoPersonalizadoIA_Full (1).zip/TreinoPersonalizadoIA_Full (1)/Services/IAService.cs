using TreinoPersonalizadoIA_Full.Models;

namespace TreinoPersonalizadoIA_Full.Services
{
    public class IAService
    {
        public SugestaoTreino GerarTreino(UsuarioDados dados)
        {
            var treino = new SugestaoTreino();

            if (dados == null || string.IsNullOrEmpty(dados.Objetivo))
            {
                treino.Treino = "Dados incompletos.";
                return treino;
            }

            switch (dados.Objetivo)
            {
                case "Ganhar Massa":
                    treino.Treino = "Treino para hipertrofia.";
                    break;
                case "Perder Gordura":
                    treino.Treino = "Treino para definição muscular.";
                    break;
                case "Força":
                    treino.Treino = "Treino voltado para força.";
                    break;
                default:
                    treino.Treino = "Objetivo não reconhecido.";
                    break;
            }

            treino.PlanoSemanal = "Seg, Qua, Sex - Musculação.";
            treino.DietaSugerida = "Proteínas e calorias controladas.";

            return treino;
        }
    }
}